import * as handpose from '@tensorflow-models/handpose';

export const detectSign = async (predictions: handpose.AnnotatedPrediction[], videoWidth: number, videoHeight: number) => {
  if (!predictions || predictions.length === 0) {
    return { sign: null, confidence: 0 };
  }
  
  const landmarks = predictions[0].landmarks;
  const palmPosition = landmarks[0];
  
  const xRatio = palmPosition[0] / videoWidth;
  const yRatio = palmPosition[1] / videoHeight;
  
  const indexFingerTip = landmarks[8];
  const middleFingerTip = landmarks[12];
  const ringFingerTip = landmarks[16];
  const pinkyTip = landmarks[20];
  const thumbTip = landmarks[4];
  
  // Calculate distances and angles for better gesture recognition
  const thumbToPalmDistance = getDistance(thumbTip, palmPosition);
  const indexToPalmDistance = getDistance(indexFingerTip, palmPosition);
  const middleToPalmDistance = getDistance(middleFingerTip, palmPosition);
  const ringToPalmDistance = getDistance(ringFingerTip, palmPosition);
  const pinkyToPalmDistance = getDistance(pinkyTip, palmPosition);
  
  // Calculate angles between fingers for more accurate detection
  const indexMiddleAngle = getAngle(indexFingerTip, palmPosition, middleFingerTip);
  const middleRingAngle = getAngle(middleFingerTip, palmPosition, ringFingerTip);
  
  let sign = null;
  let confidence = 0;

  // Enhanced gesture detection with more precise conditions
  if (yRatio < 0.3 && Math.abs(xRatio - 0.5) < 0.2) {
    // Fever - palm near forehead
    sign = "FEVER";
    confidence = 0.85;
  } 
  else if (yRatio > 0.4 && yRatio < 0.6 && Math.abs(xRatio - 0.5) < 0.2) {
    // Cold - hand near nose/mouth
    sign = "COLD";
    confidence = 0.8;
  }
  else if (
    indexToPalmDistance > 100 &&
    middleToPalmDistance > 100 &&
    indexMiddleAngle < 20 &&
    ringToPalmDistance < 70 &&
    pinkyToPalmDistance < 70
  ) {
    // Pain - index and middle fingers extended together
    sign = "PAIN";
    confidence = 0.75;
  }
  else if (yRatio < 0.4 && xRatio > 0.6) {
    // Headache - hand near temple
    sign = "HEADACHE";
    confidence = 0.7;
  }
  else if (yRatio > 0.7 && Math.abs(xRatio - 0.5) < 0.3) {
    // Nausea - hand near stomach
    sign = "NAUSEA";
    confidence = 0.75;
  }
  else if (
    yRatio < 0.4 &&
    xRatio > 0.4 &&
    xRatio < 0.6 &&
    allFingersExtended(landmarks)
  ) {
    // Dizzy - open palm near head
    sign = "DIZZY";
    confidence = 0.7;
  }
  else if (
    yRatio > 0.4 &&
    yRatio < 0.7 &&
    allFingersRelaxed(landmarks)
  ) {
    // Tired - relaxed hand position
    sign = "TIRED";
    confidence = 0.65;
  }
  else if (
    yRatio < 0.5 &&
    fingersInScratchPosition(landmarks)
  ) {
    // Allergic - scratching motion
    sign = "ALLERGIC";
    confidence = 0.7;
  }
  else if (
    yRatio > 0.4 &&
    yRatio < 0.7 &&
    Math.abs(xRatio - 0.5) < 0.2 &&
    palmFacingCamera(landmarks)
  ) {
    // Breathing difficulty - palm on chest
    sign = "BREATHING DIFFICULTY";
    confidence = 0.75;
  }
  else if (
    indexToPalmDistance > middleToPalmDistance * 1.5 &&
    indexToPalmDistance > ringToPalmDistance * 1.5 &&
    indexToPalmDistance > pinkyToPalmDistance * 1.5
  ) {
    // Injury - pointing gesture
    sign = "INJURY";
    confidence = 0.7;
  }
  
  return { sign, confidence };
};

// Helper functions for improved gesture detection
function getDistance(point1: number[], point2: number[]): number {
  return Math.sqrt(
    Math.pow(point1[0] - point2[0], 2) +
    Math.pow(point1[1] - point2[1], 2)
  );
}

function getAngle(point1: number[], center: number[], point2: number[]): number {
  const angle1 = Math.atan2(point1[1] - center[1], point1[0] - center[0]);
  const angle2 = Math.atan2(point2[1] - center[1], point2[0] - center[0]);
  return Math.abs(angle1 - angle2) * (180 / Math.PI);
}

function allFingersExtended(landmarks: number[][]): boolean {
  const fingerTips = [4, 8, 12, 16, 20];
  const fingerBases = [2, 5, 9, 13, 17];
  
  return fingerTips.every((tip, index) => {
    const distance = getDistance(landmarks[tip], landmarks[fingerBases[index]]);
    return distance > 50;
  });
}

function allFingersRelaxed(landmarks: number[][]): boolean {
  const fingerTips = [4, 8, 12, 16, 20];
  const fingerBases = [2, 5, 9, 13, 17];
  
  const distances = fingerTips.map((tip, index) =>
    getDistance(landmarks[tip], landmarks[fingerBases[index]])
  );
  
  const avgDistance = distances.reduce((a, b) => a + b, 0) / distances.length;
  return distances.every(d => Math.abs(d - avgDistance) < 20);
}

function fingersInScratchPosition(landmarks: number[][]): boolean {
  const fingerTips = [8, 12, 16, 20];
  return fingerTips.every(tip => {
    const distance = getDistance(landmarks[tip], landmarks[0]);
    return distance < 100;
  });
}

function palmFacingCamera(landmarks: number[][]): boolean {
  const palmWidth = getDistance(landmarks[5], landmarks[17]);
  const palmHeight = getDistance(landmarks[0], landmarks[9]);
  return palmWidth > palmHeight * 0.8;
}

export const drawHandMesh = (
  ctx: CanvasRenderingContext2D,
  predictions: handpose.AnnotatedPrediction[]
) => {
  if (!predictions || predictions.length === 0) {
    return;
  }
  
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  
  predictions.forEach((prediction) => {
    const landmarks = prediction.landmarks;
    
    for (let i = 0; i < landmarks.length; i++) {
      const [x, y] = landmarks[i];
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, 2 * Math.PI);
      ctx.fillStyle = 'aqua';
      ctx.fill();
    }
    
    const fingers = [
      [0, 1, 2, 3, 4],
      [0, 5, 6, 7, 8],
      [0, 9, 10, 11, 12],
      [0, 13, 14, 15, 16],
      [0, 17, 18, 19, 20],
    ];
    
    fingers.forEach((finger) => {
      for (let i = 0; i < finger.length - 1; i++) {
        const [x1, y1] = landmarks[finger[i]];
        const [x2, y2] = landmarks[finger[i + 1]];
        
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = 'aqua';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
  });
};