import React, { useState } from 'react';
import { Search, Info } from 'lucide-react';

// Define medical terms with their sign descriptions
const medicalTerms = [
  {
    id: 1,
    term: 'Fever',
    description: 'The sign for fever involves placing your palm on your forehead, indicating high temperature.',
    imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'symptoms'
  },
  {
    id: 2,
    term: 'Cold',
    description: 'The sign for cold involves making a fist and placing it near your nose, then moving it downward while opening your fingers, mimicking a runny nose.',
    imageUrl: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'symptoms'
  },
  {
    id: 3,
    term: 'Pain',
    description: 'The sign for pain involves extending your index fingers and bringing them together in front of your body, with a facial expression showing discomfort.',
    imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'symptoms'
  },
  {
    id: 4,
    term: 'Headache',
    description: 'The sign for headache involves placing your fingertips on your temples and making small circular motions.',
    imageUrl: 'https://images.unsplash.com/photo-1541199249251-f713e6145474?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'symptoms'
  },
  {
    id: 5,
    term: 'Nausea',
    description: 'The sign for nausea involves placing your hand on your stomach and moving it in a circular motion while showing discomfort in your facial expression.',
    imageUrl: 'https://images.unsplash.com/photo-1616784754551-dea42ea33356?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'symptoms'
  },
  {
    id: 6,
    term: 'Medication',
    description: 'The sign for medication involves mimicking taking a pill by bringing your hand to your mouth.',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'treatment'
  },
  {
    id: 7,
    term: 'Doctor',
    description: 'The sign for doctor involves making a "D" handshape and placing it against your wrist, as if taking a pulse.',
    imageUrl: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'healthcare'
  },
  {
    id: 8,
    term: 'Hospital',
    description: 'The sign for hospital involves making an "H" handshape and moving it in a cross pattern, representing the symbol for hospital.',
    imageUrl: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'healthcare'
  },
  {
    id: 9,
    term: 'Emergency',
    description: 'The sign for emergency involves making an "E" handshape and moving it in a circular motion in front of your body.',
    imageUrl: 'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'healthcare'
  },
  {
    id: 10,
    term: 'Allergy',
    description: 'The sign for allergy involves making an "A" handshape and moving it in a scratching motion on your arm.',
    imageUrl: 'https://images.unsplash.com/photo-1616578492900-ea5d76128eac?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'conditions'
  },
  {
    id: 11,
    term: 'Diabetes',
    description: 'The sign for diabetes involves making a "D" handshape and mimicking an injection in your arm.',
    imageUrl: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'conditions'
  },
  {
    id: 12,
    term: 'Heart Attack',
    description: 'The sign for heart attack involves making a fist and placing it on your chest, then opening your fingers quickly.',
    imageUrl: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    category: 'emergency'
  }
];

// Define categories
const categories = [
  { id: 'all', name: 'All Terms' },
  { id: 'symptoms', name: 'Symptoms' },
  { id: 'conditions', name: 'Conditions' },
  { id: 'treatment', name: 'Treatment' },
  { id: 'healthcare', name: 'Healthcare' },
  { id: 'emergency', name: 'Emergency' }
];

export const MedicalTerminology: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Filter terms based on search and category
  const filteredTerms = medicalTerms.filter(term => {
    const matchesSearch = term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          term.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || term.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-900">Medical Sign Language Terminology</h1>
          <p className="mt-2 text-gray-600">
            Learn common American Sign Language (ASL) signs for medical terms to better communicate during healthcare visits.
          </p>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 space-y-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Search medical terms..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  selectedCategory === category.id
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Medical Terms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTerms.length > 0 ? (
          filteredTerms.map(term => (
            <div key={term.id} className="bg-white rounded-xl shadow-md overflow-hidden">
              <img
                src={term.imageUrl}
                alt={term.term}
                className="h-48 w-full object-cover"
              />
              <div className="p-6">
                <h3 className="text-lg font-bold text-gray-900">{term.term}</h3>
                <span className="inline-block px-2 py-1 mt-2 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                  {term.category.charAt(0).toUpperCase() + term.category.slice(1)}
                </span>
                <p className="mt-3 text-gray-600">{term.description}</p>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full bg-gray-50 rounded-xl p-8 text-center">
            <p className="text-gray-500">No medical terms found matching your search criteria.</p>
          </div>
        )}
      </div>

      {/* Learning Resources */}
      <div className="bg-blue-50 rounded-xl p-6">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <Info className="h-5 w-5 text-blue-400" />
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Learning Resources</h3>
            <p className="mt-2 text-sm text-blue-700">
              This is a simplified guide to common medical signs in ASL. For comprehensive learning, 
              we recommend consulting with a certified ASL interpreter or taking classes from 
              organizations specializing in medical sign language.
            </p>
            <div className="mt-3">
              <a href="#" className="text-sm font-medium text-blue-600 hover:text-blue-500">
                Download our complete medical signs PDF guide
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};