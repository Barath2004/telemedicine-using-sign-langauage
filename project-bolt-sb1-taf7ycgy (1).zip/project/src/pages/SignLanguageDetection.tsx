import React, { useRef, useState, useEffect } from 'react';
import Webcam from 'react-webcam';
import { AlertCircle, Camera, CheckCircle, Info } from 'lucide-react';
import * as tf from '@tensorflow/tfjs';
import * as handpose from '@tensorflow-models/handpose';
import { detectSign } from '../utils/handPoseUtils';

export const SignLanguageDetection: React.FC = () => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isWebcamReady, setIsWebcamReady] = useState(false);
  const [hasWebcamPermission, setHasWebcamPermission] = useState<boolean | null>(null);
  const [model, setModel] = useState<handpose.HandPose | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [detectedSign, setDetectedSign] = useState<string | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectionConfidence, setDetectionConfidence] = useState(0);

  const videoConstraints = {
    width: 640,
    height: 480,
    facingMode: "user",
    mirrored: true
  };

  useEffect(() => {
    const loadModel = async () => {
      try {
        await tf.ready();
        const handposeModel = await handpose.load();
        setModel(handposeModel);
        setIsModelLoading(false);
      } catch (error) {
        console.error('Error loading handpose model:', error);
        setIsModelLoading(false);
      }
    };

    loadModel();
  }, []);

  const handleUserMedia = () => {
    setIsWebcamReady(true);
    setHasWebcamPermission(true);
  };

  const handleUserMediaError = () => {
    setHasWebcamPermission(false);
  };

  const runHandpose = async () => {
    if (!model || !webcamRef.current?.video || !isDetecting) return;
    
    try {
      const video = webcamRef.current.video;
      const videoWidth = video.videoWidth;
      const videoHeight = video.videoHeight;
      
      video.width = videoWidth;
      video.height = videoHeight;

      if (canvasRef.current) {
        canvasRef.current.width = videoWidth;
        canvasRef.current.height = videoHeight;
      }
      
      const predictions = await model.estimateHands(video);
      
      if (predictions.length > 0) {
        const landmarks = predictions[0].landmarks;
        
        if (canvasRef.current) {
          const ctx = canvasRef.current.getContext('2d');
          if (ctx) {
            ctx.clearRect(0, 0, videoWidth, videoHeight);
            ctx.save();
            ctx.scale(-1, 1);
            ctx.translate(-videoWidth, 0);
            
            // Draw dots at each landmark
            for (let i = 0; i < landmarks.length; i++) {
              const [x, y] = landmarks[i];
              ctx.beginPath();
              ctx.arc(x, y, 5, 0, 2 * Math.PI);
              ctx.fillStyle = 'aqua';
              ctx.fill();
            }
            
            // Draw lines connecting landmarks
            const fingers = [
              [0, 1, 2, 3, 4],
              [0, 5, 6, 7, 8],
              [0, 9, 10, 11, 12],
              [0, 13, 14, 15, 16],
              [0, 17, 18, 19, 20],
            ];
            
            fingers.forEach((finger) => {
              for (let i = 0; i < finger.length - 1; i++) {
                const [x1, y1] = landmarks[finger[i]];
                const [x2, y2] = landmarks[finger[i + 1]];
                
                ctx.beginPath();
                ctx.moveTo(x1, y1);
                ctx.lineTo(x2, y2);
                ctx.strokeStyle = 'aqua';
                ctx.lineWidth = 2;
                ctx.stroke();
              }
            });
            
            ctx.restore();
          }
        }
        
        const { sign, confidence } = await detectSign(predictions, videoWidth, videoHeight);
        
        if (sign && confidence > 0.5) {
          setDetectedSign(sign);
          setDetectionConfidence(confidence);
        }
      } else {
        setDetectedSign(null);
        setDetectionConfidence(0);
      }
    } catch (error) {
      console.error('Error during hand detection:', error);
    }
    
    if (isDetecting) {
      requestAnimationFrame(runHandpose);
    }
  };

  useEffect(() => {
    if (isDetecting && model && webcamRef.current?.video) {
      runHandpose();
    }
  }, [isDetecting, model, webcamRef.current?.video]);

  const toggleDetection = () => {
    setIsDetecting(!isDetecting);
  };

  const signInstructions = [
    { sign: 'Fever', instruction: 'Place your palm on your forehead' },
    { sign: 'Cold', instruction: 'Place your hand near your nose/mouth' },
    { sign: 'Pain', instruction: 'Extend your index and middle fingers together' },
    { sign: 'Headache', instruction: 'Place your hand near your temple' },
    { sign: 'Nausea', instruction: 'Place your hand near your stomach' },
    { sign: 'Dizzy', instruction: 'Make a circular motion near your head' },
    { sign: 'Tired', instruction: 'Hold your palm facing up with relaxed fingers' },
    { sign: 'Allergic', instruction: 'Make a scratching motion near your face' },
    { sign: 'Breathing Difficulty', instruction: 'Place your hand on your chest' },
    { sign: 'Injury', instruction: 'Point with your index finger to the affected area' }
  ];

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-900">Sign Language Detection</h1>
          <p className="mt-2 text-gray-600">
            Use your webcam to communicate using American Sign Language. Our AI will detect and interpret common medical signs.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          {isModelLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
              <p className="mt-4 text-gray-600">Loading sign language detection model...</p>
            </div>
          ) : (
            <>
              {hasWebcamPermission === false ? (
                <div className="bg-red-50 border border-red-200 rounded-md p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <AlertCircle className="h-5 w-5 text-red-400" />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-red-800">Webcam access denied</h3>
                      <div className="mt-2 text-sm text-red-700">
                        Please allow access to your camera to use the sign language detection feature.
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="webcam-container bg-gray-100 rounded-lg overflow-hidden relative">
                    <Webcam
                      ref={webcamRef}
                      audio={false}
                      screenshotFormat="image/jpeg"
                      videoConstraints={videoConstraints}
                      onUserMedia={handleUserMedia}
                      onUserMediaError={handleUserMediaError}
                      className="w-full"
                      style={{ transform: 'scaleX(-1)' }}
                    />
                    
                    <canvas
                      ref={canvasRef}
                      className="absolute top-0 left-0 w-full h-full"
                    />
                    
                    {detectedSign && (
                      <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
                        <div className="bg-white bg-opacity-90 px-4 py-2 rounded-lg shadow-lg">
                          <p className="text-xl font-bold text-blue-600">{detectedSign}</p>
                          <p className="text-sm text-blue-500">
                            Confidence: {Math.round(detectionConfidence * 100)}%
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <button
                      onClick={toggleDetection}
                      className={`px-4 py-2 rounded-md font-medium ${
                        isDetecting
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                      }`}
                    >
                      {isDetecting ? 'Stop Detection' : 'Start Detection'}
                    </button>
                    
                    <div className="flex items-center text-sm text-gray-500">
                      <Info className="h-4 w-4 mr-1" />
                      {isDetecting ? (
                        <span className="flex items-center">
                          <span className="relative flex h-3 w-3 mr-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                          </span>
                          Actively detecting signs
                        </span>
                      ) : (
                        'Detection paused'
                      )}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h2 className="text-xl font-bold text-gray-900">Available Signs</h2>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            {signInstructions.map((item, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-6 w-6 rounded-full bg-blue-100 text-blue-600 text-sm">
                    {index + 1}
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">{item.sign}</h3>
                  <div className="mt-1 text-sm text-gray-500">{item.instruction}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-blue-50 rounded-xl p-6">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <Info className="h-5 w-5 text-blue-400" />
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">About this feature</h3>
            <div className="mt-2 text-sm text-blue-700">
              This is a demonstration of sign language detection technology. For best results, ensure you have good lighting
              and position your hand clearly in the frame. The detection works best when your hand gestures are clear and deliberate.
              Visit our Medical Terms page to learn more about medical signs.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};