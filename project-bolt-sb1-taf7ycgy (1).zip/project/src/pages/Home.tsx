import React from 'react';
import { Link } from 'react-router-dom';
import { Video, BookOpen, MessageSquare, ArrowRight } from 'lucide-react';

export const Home: React.FC = () => {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="bg-blue-600 rounded-xl shadow-xl overflow-hidden">
        <div className="px-6 py-12 md:px-12 md:py-16 md:flex md:items-center">
          <div className="md:w-1/2 md:pr-10">
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              Breaking Medical Communication Barriers with Sign Language
            </h1>
            <p className="mt-4 text-lg text-blue-100">
              Our telemedicine platform bridges the gap between healthcare providers and patients using American Sign Language (ASL).
            </p>
            <div className="mt-8">
              <Link
                to="/sign-detection"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50 shadow-md"
              >
                Try Sign Detection
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
          <div className="mt-10 md:mt-0 md:w-1/2">
            <img
              src="https://images.unsplash.com/photo-1573497620053-ea5300f94f21?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80"
              alt="Doctor using sign language"
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-8">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">
          How SignMed Helps You
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Video className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Sign Language Detection</h3>
            <p className="mt-2 text-gray-600">
              Our AI-powered system recognizes American Sign Language in real-time through your webcam.
            </p>
            <Link
              to="/sign-detection"
              className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-800"
            >
              Try it now <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <BookOpen className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Medical Terminology</h3>
            <p className="mt-2 text-gray-600">
              Learn common medical signs for symptoms like fever, cold, pain, and more with our visual guide.
            </p>
            <Link
              to="/medical-terms"
              className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-800"
            >
              View library <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <MessageSquare className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Virtual Consultations</h3>
            <p className="mt-2 text-gray-600">
              Connect with healthcare providers who understand sign language or use our translation tools.
            </p>
            <Link
              to="/consultation"
              className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-800"
            >
              Start a session <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="px-6 py-8 md:p-10">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
            What Our Users Say
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-600 italic">
                "SignMed has transformed how I communicate with my doctor. I no longer need an interpreter for basic consultations."
              </p>
              <div className="mt-4 flex items-center">
                <div className="flex-shrink-0">
                  <img
                    className="h-10 w-10 rounded-full"
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                    alt="User"
                  />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Sarah Johnson</p>
                  <p className="text-sm text-gray-500">Patient</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-600 italic">
                "As a healthcare provider, this platform has helped me better serve my patients who use sign language."
              </p>
              <div className="mt-4 flex items-center">
                <div className="flex-shrink-0">
                  <img
                    className="h-10 w-10 rounded-full"
                    src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                    alt="Doctor"
                  />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Dr. Michael Chen</p>
                  <p className="text-sm text-gray-500">Physician</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-50 rounded-xl p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-900">Ready to get started?</h2>
        <p className="mt-2 text-lg text-gray-600 max-w-2xl mx-auto">
          Experience the future of accessible healthcare communication today.
        </p>
        <div className="mt-6">
          <Link
            to="/sign-detection"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 shadow-md"
          >
            Try Sign Detection
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};