import React, { useState } from 'react';
import { Calendar, Clock, Video, MessageSquare, AlertCircle } from 'lucide-react';

export const Consultation: React.FC = () => {
  const [consultationType, setConsultationType] = useState<string>('video');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [symptoms, setSymptoms] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  
  // Available dates (next 7 days)
  const availableDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    return date.toISOString().split('T')[0];
  });
  
  // Available time slots
  const availableTimes = [
    '09:00 AM', '10:00 AM', '11:00 AM', 
    '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM'
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };
  
  if (isSubmitted) {
    return (
      <div className="bg-white rounded-xl shadow-md overflow-hidden p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
          <CheckCircle className="h-6 w-6 text-green-600" aria-hidden="true" />
        </div>
        <h2 className="mt-6 text-2xl font-bold text-gray-900">Consultation Scheduled</h2>
        <p className="mt-2 text-gray-600">
          Your {consultationType} consultation has been scheduled for {selectedDate} at {selectedTime}.
        </p>
        <p className="mt-4 text-gray-600">
          You will receive a confirmation email at {email} with details and instructions.
        </p>
        <div className="mt-6">
          <button
            onClick={() => setIsSubmitted(false)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Schedule Another Consultation
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-900">Schedule a Consultation</h1>
          <p className="mt-2 text-gray-600">
            Connect with healthcare providers who understand sign language or use our translation services.
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-6">
              <h2 className="text-lg font-medium text-gray-900">Consultation Details</h2>
              
              <form onSubmit={handleSubmit} className="mt-6 space-y-6">
                {/* Consultation Type */}
                <div>
                  <label className="text-sm font-medium text-gray-700">Consultation Type</label>
                  <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div
                      className={`relative rounded-lg border ${
                        consultationType === 'video'
                          ? 'bg-blue-50 border-blue-200'
                          : 'border-gray-300 hover:border-gray-400'
                      } p-4 flex cursor-pointer focus:outline-none`}
                      onClick={() => setConsultationType('video')}
                    >
                      <div className="flex items-center">
                        <div className={`flex-shrink-0 h-6 w-6 ${
                          consultationType === 'video' ? 'text-blue-600' : 'text-gray-400'
                        }`}>
                          <Video className="h-6 w-6" />
                        </div>
                        <div className="ml-3">
                          <h3 className="text-sm font-medium text-gray-900">Video Consultation</h3>
                          <p className="text-xs text-gray-500">With sign language support</p>
                        </div>
                      </div>
                    </div>
                    
                    <div
                      className={`relative rounded-lg border ${
                        consultationType === 'chat'
                          ? 'bg-blue-50 border-blue-200'
                          : 'border-gray-300 hover:border-gray-400'
                      } p-4 flex cursor-pointer focus:outline-none`}
                      onClick={() => setConsultationType('chat')}
                    >
                      <div className="flex items-center">
                        <div className={`flex-shrink-0 h-6 w-6 ${
                          consultationType === 'chat' ? 'text-blue-600' : 'text-gray-400'
                        }`}>
                          <MessageSquare className="h-6 w-6" />
                        </div>
                        <div className="ml-3">
                          <h3 className="text-sm font-medium text-gray-900">Text Chat</h3>
                          <p className="text-xs text-gray-500">Text-based communication</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Date Selection */}
                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                    Select Date
                  </label>
                  <div className="mt-2">
                    <select
                      id="date"
                      name="date"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      required
                    >
                      <option value="">Select a date</option>
                      {availableDates.map(date => (
                        <option key={date} value={date}>
                          {new Date(date).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                {/* Time Selection */}
                <div>
                  <label htmlFor="time" className="block text-sm font-medium text-gray-700">
                    Select Time
                  </label>
                  <div className="mt-2 grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {availableTimes.map(time => (
                      <div
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`px-3 py-2 text-sm text-center rounded-md cursor-pointer ${
                          selectedTime === time
                            ? 'bg-blue-100 text-blue-800 font-medium'
                            : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                        }`}
                      >
                        {time}
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Symptoms/Reason */}
                <div>
                  <label htmlFor="symptoms" className="block text-sm font-medium text-gray-700">
                    Symptoms or Reason for Visit
                  </label>
                  <div className="mt-1">
                    <textarea
                      id="symptoms"
                      name="symptoms"
                      rows={3}
                      className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      placeholder="Briefly describe your symptoms or reason for consultation"
                      value={symptoms}
                      onChange={(e) => setSymptoms(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                {/* Personal Information */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Full Name
                    </label>
                    <div className="mt-1">
                      <input
                        type="text"
                        id="name"
                        name="name"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email Address
                    </label>
                    <div className="mt-1">
                      <input
                        type="email"
                        id="email"
                        name="email"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                
                {/* Submit Button */}
                <div>
                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="animate-spin mr-2">⟳</span>
                        Scheduling...
                      </>
                    ) : (
                      'Schedule Consultation'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div>
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-6">
              <h2 className="text-lg font-medium text-gray-900">About Our Consultations</h2>
              
              <div className="mt-6 space-y-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100 text-blue-600">
                      <Video className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-900">Video Consultations</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Connect face-to-face with healthcare providers who understand sign language or use our real-time translation service.
                    </p>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100 text-blue-600">
                      <MessageSquare className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-900">Text Chat</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Communicate through text if you prefer written communication over video.
                    </p>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100 text-blue-600">
                      <Calendar className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-900">Flexible Scheduling</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Choose from available time slots that work best for your schedule.
                    </p>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100 text-blue-600">
                      <Clock className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-900">30-Minute Sessions</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Each consultation lasts approximately 30 minutes, with options to extend if needed.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-md p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-yellow-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-yellow-800">Important Note</h3>
                    <p className="mt-2 text-sm text-yellow-700">
                      This service is not intended for emergency situations. If you are experiencing a medical emergency, please call emergency services immediately.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Add CheckCircle component for the success message
const CheckCircle: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  );
};